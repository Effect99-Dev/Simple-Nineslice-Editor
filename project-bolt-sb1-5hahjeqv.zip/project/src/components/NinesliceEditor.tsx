import React, { useState, useRef, useCallback, useEffect } from 'react';
import { Upload, Download, RotateCcw } from 'lucide-react';

interface NinesliceData {
  left: number;
  top: number;
  right: number;
  bottom: number;
}

interface PreviewSize {
  width: number;
  height: number;
}

const NinesliceEditor: React.FC = () => {
  const [image, setImage] = useState<HTMLImageElement | null>(null);
  const [imageUrl, setImageUrl] = useState<string>('');
  const [nineslice, setNineslice] = useState<NinesliceData>({ left: 20, top: 20, right: 20, bottom: 20 });
  const [previewSize, setPreviewSize] = useState<PreviewSize>({ width: 200, height: 150 });
  const [isDragging, setIsDragging] = useState<string | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const previewCanvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setImageUrl(url);
      
      const img = new Image();
      img.onload = () => {
        setImage(img);
        // Reset nineslice values based on image size
        const defaultSlice = Math.max(1, Math.min(img.width, img.height) * 0.2);
        setNineslice({
          left: defaultSlice,
          top: defaultSlice,
          right: defaultSlice,
          bottom: defaultSlice
        });
      };
      img.src = url;
    }
  };

  const drawNinesliceEditor = useCallback(() => {
    if (!image || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Calculate scale factor to ensure minimum display size
    const minDisplaySize = 400;
    const scaleX = Math.max(1, minDisplaySize / image.width);
    const scaleY = Math.max(1, minDisplaySize / image.height);
    const scale = Math.min(scaleX, scaleY);
    
    const displayWidth = image.width * scale;
    const displayHeight = image.height * scale;
    
    canvas.width = displayWidth;
    canvas.height = displayHeight;

    // Disable image smoothing for pixel-perfect scaling
    ctx.imageSmoothingEnabled = false;
    
    // Draw the scaled image with crisp pixels
    ctx.drawImage(image, 0, 0, displayWidth, displayHeight);

    // Draw grid lines
    ctx.strokeStyle = '#ff4444';
    ctx.lineWidth = Math.max(1, 2 / scale); // Adjust line width based on scale
    ctx.setLineDash([5, 5]);

    // Vertical lines
    ctx.beginPath();
    ctx.moveTo(nineslice.left * scale, 0);
    ctx.lineTo(nineslice.left * scale, displayHeight);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(displayWidth - nineslice.right * scale, 0);
    ctx.lineTo(displayWidth - nineslice.right * scale, displayHeight);
    ctx.stroke();

    // Horizontal lines
    ctx.beginPath();
    ctx.moveTo(0, nineslice.top * scale);
    ctx.lineTo(displayWidth, nineslice.top * scale);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(0, displayHeight - nineslice.bottom * scale);
    ctx.lineTo(displayWidth, displayHeight - nineslice.bottom * scale);
    ctx.stroke();

    ctx.setLineDash([]);

    // Draw handles
    ctx.fillStyle = '#ff4444';
    const handleSize = Math.max(8, Math.min(16, 12 / Math.sqrt(scale))); // Smaller handles for very scaled images

    // Left handle
    ctx.fillRect(nineslice.left * scale - handleSize/2, displayHeight/2 - handleSize/2, handleSize, handleSize);
    
    // Right handle
    ctx.fillRect(displayWidth - nineslice.right * scale - handleSize/2, displayHeight/2 - handleSize/2, handleSize, handleSize);
    
    // Top handle
    ctx.fillRect(displayWidth/2 - handleSize/2, nineslice.top * scale - handleSize/2, handleSize, handleSize);
    
    // Bottom handle
    ctx.fillRect(displayWidth/2 - handleSize/2, displayHeight - nineslice.bottom * scale - handleSize/2, handleSize, handleSize);

    // Draw section labels
    ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
    ctx.font = `${Math.max(10, Math.min(16, 14 / Math.sqrt(scale)))}px Arial`; // Reasonable font size
    ctx.textAlign = 'center';

    const sections = [
      { x: (nineslice.left * scale)/2, y: (nineslice.top * scale)/2, text: '1' },
      { x: nineslice.left * scale + (displayWidth - nineslice.left * scale - nineslice.right * scale)/2, y: (nineslice.top * scale)/2, text: '2' },
      { x: displayWidth - (nineslice.right * scale)/2, y: (nineslice.top * scale)/2, text: '3' },
      { x: (nineslice.left * scale)/2, y: nineslice.top * scale + (displayHeight - nineslice.top * scale - nineslice.bottom * scale)/2, text: '4' },
      { x: nineslice.left * scale + (displayWidth - nineslice.left * scale - nineslice.right * scale)/2, y: nineslice.top * scale + (displayHeight - nineslice.top * scale - nineslice.bottom * scale)/2, text: '5' },
      { x: displayWidth - (nineslice.right * scale)/2, y: nineslice.top * scale + (displayHeight - nineslice.top * scale - nineslice.bottom * scale)/2, text: '6' },
      { x: (nineslice.left * scale)/2, y: displayHeight - (nineslice.bottom * scale)/2, text: '7' },
      { x: nineslice.left * scale + (displayWidth - nineslice.left * scale - nineslice.right * scale)/2, y: displayHeight - (nineslice.bottom * scale)/2, text: '8' },
      { x: displayWidth - (nineslice.right * scale)/2, y: displayHeight - (nineslice.bottom * scale)/2, text: '9' }
    ];

    sections.forEach(section => {
      ctx.fillText(section.text, section.x, section.y);
    });
  }, [image, nineslice]);

  const drawNineslicePreview = useCallback(() => {
    if (!image || !previewCanvasRef.current) return;

    const canvas = previewCanvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = previewSize.width;
    canvas.height = previewSize.height;

    // Disable image smoothing for crisp pixel rendering
    ctx.imageSmoothingEnabled = false;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw nineslice preview
    const { left, top, right, bottom } = nineslice;
    const srcW = image.width;
    const srcH = image.height;
    const dstW = previewSize.width;
    const dstH = previewSize.height;

    // Corner pieces (fixed size)
    // Top-left
    ctx.drawImage(image, 0, 0, left, top, 0, 0, left, top);
    
    // Top-right
    ctx.drawImage(image, srcW - right, 0, right, top, dstW - right, 0, right, top);
    
    // Bottom-left
    ctx.drawImage(image, 0, srcH - bottom, left, bottom, 0, dstH - bottom, left, bottom);
    
    // Bottom-right
    ctx.drawImage(image, srcW - right, srcH - bottom, right, bottom, dstW - right, dstH - bottom, right, bottom);

    // Edge pieces (stretched)
    // Top edge
    ctx.drawImage(image, left, 0, srcW - left - right, top, left, 0, dstW - left - right, top);
    
    // Bottom edge
    ctx.drawImage(image, left, srcH - bottom, srcW - left - right, bottom, left, dstH - bottom, dstW - left - right, bottom);
    
    // Left edge
    ctx.drawImage(image, 0, top, left, srcH - top - bottom, 0, top, left, dstH - top - bottom);
    
    // Right edge
    ctx.drawImage(image, srcW - right, top, right, srcH - top - bottom, dstW - right, top, right, dstH - top - bottom);

    // Center piece (stretched)
    ctx.drawImage(
      image,
      left, top, srcW - left - right, srcH - top - bottom,
      left, top, dstW - left - right, dstH - top - bottom
    );
  }, [image, nineslice, previewSize]);

  const handleCanvasMouseDown = (event: React.MouseEvent<HTMLCanvasElement>) => {
    if (!image) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    // Calculate scale factor
    const minDisplaySize = 400;
    const scaleX = Math.max(1, minDisplaySize / image.width);
    const scaleY = Math.max(1, minDisplaySize / image.height);
    const scale = Math.min(scaleX, scaleY);

    const rect = canvas.getBoundingClientRect();
    const x = (event.clientX - rect.left);
    const y = (event.clientY - rect.top);

    const handleSize = Math.max(8, Math.min(16, 12 / Math.sqrt(scale)));
    const displayWidth = image.width * scale;
    const displayHeight = image.height * scale;

    // Check which handle was clicked
    const scaledX = x * (canvas.width / rect.width);
    const scaledY = y * (canvas.height / rect.height);
    
    if (Math.abs(scaledX - nineslice.left * scale) < handleSize + 10 && Math.abs(scaledY - displayHeight/2) < handleSize + 10) {
      setIsDragging('left');
    } else if (Math.abs(scaledX - (displayWidth - nineslice.right * scale)) < handleSize + 10 && Math.abs(scaledY - displayHeight/2) < handleSize + 10) {
      setIsDragging('right');
    } else if (Math.abs(scaledX - displayWidth/2) < handleSize + 10 && Math.abs(scaledY - nineslice.top * scale) < handleSize + 10) {
      setIsDragging('top');
    } else if (Math.abs(scaledX - displayWidth/2) < handleSize + 10 && Math.abs(scaledY - (displayHeight - nineslice.bottom * scale)) < handleSize + 10) {
      setIsDragging('bottom');
    }
  };

  const handleCanvasMouseMove = (event: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDragging || !image) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    // Calculate scale factor
    const minDisplaySize = 400;
    const scaleX = Math.max(1, minDisplaySize / image.width);
    const scaleY = Math.max(1, minDisplaySize / image.height);
    const scale = Math.min(scaleX, scaleY);

    const rect = canvas.getBoundingClientRect();
    const x = (event.clientX - rect.left);
    const y = (event.clientY - rect.top);
    
    // Convert to canvas coordinates
    const scaledX = x * (canvas.width / rect.width);
    const scaledY = y * (canvas.height / rect.height);

    // Convert display coordinates back to original image coordinates
    const originalX = scaledX / scale;
    const originalY = scaledY / scale;

    const newNineslice = { ...nineslice };

    switch (isDragging) {
      case 'left':
        newNineslice.left = Math.max(1, Math.min(originalX, image.width - nineslice.right - 1));
        break;
      case 'right':
        newNineslice.right = Math.max(1, Math.min(image.width - originalX, image.width - nineslice.left - 1));
        break;
      case 'top':
        newNineslice.top = Math.max(1, Math.min(originalY, image.height - nineslice.bottom - 1));
        break;
      case 'bottom':
        newNineslice.bottom = Math.max(1, Math.min(image.height - originalY, image.height - nineslice.top - 1));
        break;
    }

    setNineslice(newNineslice);
  };

  const handleCanvasMouseUp = () => {
    setIsDragging(null);
  };

  const resetNineslice = () => {
    if (image) {
      const defaultSlice = Math.max(1, Math.min(image.width, image.height) * 0.2);
      setNineslice({
        left: defaultSlice,
        top: defaultSlice,
        right: defaultSlice,
        bottom: defaultSlice
      });
    }
  };

  const exportData = () => {
    if (!image) return;

    const data = {
      nineslice_size: [nineslice.left, nineslice.top, nineslice.right, nineslice.bottom],
      base_size: [image.width, image.height],
      image_url: imageUrl
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'nineslice_data.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  useEffect(() => {
    drawNinesliceEditor();
  }, [drawNinesliceEditor]);

  useEffect(() => {
    drawNineslicePreview();
  }, [drawNineslicePreview]);

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-6 text-white">
            <h1 className="text-3xl font-bold mb-2">Nineslice Editor</h1>
            <p className="text-blue-100">Upload an image and adjust the slice boundaries to create perfect UI scaling</p>
          </div>

          <div className="p-6">
            {!image && (
              <div className="mb-6">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="flex items-center gap-2 bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded-lg transition-colors duration-200"
                >
                  <Upload size={20} />
                  Upload Image
                </button>
              </div>
            )}

            {image && (
              <div className="space-y-6">
                <div className="flex gap-4 items-center">
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="flex items-center gap-2 bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded transition-colors duration-200"
                  >
                    <Upload size={16} />
                    Change Image
                  </button>
                  <button
                    onClick={resetNineslice}
                    className="flex items-center gap-2 bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded transition-colors duration-200"
                  >
                    <RotateCcw size={16} />
                    Reset
                  </button>
                  <button
                    onClick={exportData}
                    className="flex items-center gap-2 bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded transition-colors duration-200"
                  >
                    <Download size={16} />
                    Export Data
                  </button>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Editor Canvas */}
                  <div className="space-y-4">
                    <h2 className="text-xl font-semibold text-gray-800">Editor</h2>
                    <div className="border-2 border-gray-200 rounded-lg p-4 bg-gray-50">
                      <canvas
                        ref={canvasRef}
                        className="max-w-full h-auto border border-gray-300 rounded cursor-crosshair bg-white"
                        onMouseDown={handleCanvasMouseDown}
                        onMouseMove={handleCanvasMouseMove}
                        onMouseUp={handleCanvasMouseUp}
                        onMouseLeave={handleCanvasMouseUp}
                      />
                      <p className="text-sm text-gray-600 mt-2">
                        Drag the red handles to adjust slice boundaries. Small images are automatically scaled up for easier editing.
                      </p>
                    </div>

                    {/* Manual Controls */}
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Left</label>
                        <input
                          type="number"
                          min="1"
                          max={image ? image.width - nineslice.right - 1 : undefined}
                          value={Math.round(nineslice.left)}
                          onChange={(e) => setNineslice(prev => ({ ...prev, left: Math.max(1, parseInt(e.target.value) || 1) }))}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Top</label>
                        <input
                          type="number"
                          min="1"
                          max={image ? image.height - nineslice.bottom - 1 : undefined}
                          value={Math.round(nineslice.top)}
                          onChange={(e) => setNineslice(prev => ({ ...prev, top: Math.max(1, parseInt(e.target.value) || 1) }))}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Right</label>
                        <input
                          type="number"
                          min="1"
                          max={image ? image.width - nineslice.left - 1 : undefined}
                          value={Math.round(nineslice.right)}
                          onChange={(e) => setNineslice(prev => ({ ...prev, right: Math.max(1, parseInt(e.target.value) || 1) }))}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Bottom</label>
                        <input
                          type="number"
                          min="1"
                          max={image ? image.height - nineslice.top - 1 : undefined}
                          value={Math.round(nineslice.bottom)}
                          onChange={(e) => setNineslice(prev => ({ ...prev, bottom: Math.max(1, parseInt(e.target.value) || 1) }))}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Preview Canvas */}
                  <div className="space-y-4">
                    <h2 className="text-xl font-semibold text-gray-800">Preview</h2>
                    <div className="border-2 border-gray-200 rounded-lg p-4 bg-gray-50">
                      <canvas
                        ref={previewCanvasRef}
                        className="border border-gray-300 rounded bg-white"
                      />
                      <p className="text-sm text-gray-600 mt-2">
                        Preview of how the nineslice will scale
                      </p>
                    </div>

                    {/* Preview Size Controls */}
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Preview Width</label>
                        <input
                          type="number"
                          value={previewSize.width}
                          onChange={(e) => setPreviewSize(prev => ({ ...prev, width: parseInt(e.target.value) || 200 }))}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Preview Height</label>
                        <input
                          type="number"
                          value={previewSize.height}
                          onChange={(e) => setPreviewSize(prev => ({ ...prev, height: parseInt(e.target.value) || 150 }))}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Output Values */}
                <div className="bg-gray-800 text-white p-6 rounded-lg">
                  <h3 className="text-lg font-semibold mb-4">Output Values</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono">
                    <div>
                      <span className="text-blue-300">nineslice_size:</span>
                      <span className="ml-2 text-green-300">
                        [{Math.round(nineslice.left)}, {Math.round(nineslice.top)}, {Math.round(nineslice.right)}, {Math.round(nineslice.bottom)}]
                      </span>
                    </div>
                    <div>
                      <span className="text-blue-300">base_size:</span>
                      <span className="ml-2 text-green-300">
                        [{image.width}, {image.height}]
                      </span>
                    </div>
                  </div>
                  <div className="mt-4 text-sm text-gray-400">
                    <p><strong>nineslice_size</strong>: [left, top, right, bottom] - Border sizes in pixels</p>
                    <p><strong>base_size</strong>: [width, height] - Original image dimensions in pixels</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleImageUpload}
        className="hidden"
      />
    </div>
  );
};

export default NinesliceEditor;