import React from 'react';
import NinesliceEditor from './components/NinesliceEditor';

function App() {
  return <NinesliceEditor />;
}

export default App;